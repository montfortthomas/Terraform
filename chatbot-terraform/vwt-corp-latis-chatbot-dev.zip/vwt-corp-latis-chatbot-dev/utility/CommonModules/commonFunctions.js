'use strict';
// Import Node Modules
const AWS = require("aws-sdk");
let request = require("request");
let util = require('util');
request = util.promisify(request);
const ldap = require('ldapjs');
const awsParamStore = require('aws-param-store');

// Import functional Modules
const urlConstants = require('../LatisModules/Constants/Urls')
const Constants = require('../LatisModules/Constants/constants.json')
const errorMessages = require('./commonErrorMessages')

//Declare variables to be used
var serviceAccountUserName = "";
var serviceAccountPass = ""
var userId;

// Translation Util
exports.modeltranslation = async function (sourceLang, InputText) {
    console.log("translation input",sourceLang, InputText);
    let translatedText;
    AWS.config.update({ region: "eu-west-1" });
    var translate = new AWS.Translate({ apiVersion: "2017-07-01" });
    var params1 = {
        SourceLanguageCode: "auto" /* required */,
        TargetLanguageCode: sourceLang /* required */,
        Text: InputText /* required */,
    };
    try {
        translatedText = await translate.translateText(params1).promise();
        console.log("in translate model", translatedText);
    } catch (error) {
        console.log(error);
    }
    return translatedText.TranslatedText;
}
// Querying the LDAP to check if it is a valid user
exports.callLdapQuery = async function (userIdFromJde) {
    return new Promise(function (resolve, reject) {
        //creating a client using the FQDN
        const client = ldap.createClient({
            url: [urlConstants.ldapUrl]
        })
        try {
            // Fetching params from AWS Param Store
            let res = awsParamStore.getParameters(['serviceAccountUserName', 'serviceAccountPass'],
                { region: 'eu-west-1' }).then((results) => {
                    console.log(results);
                    return results;
                })
            res.then(function (result) {
                console.log("in the promise response console");
                console.log(result);
                serviceAccountUserName = result.Parameters[1].Value;
                serviceAccountPass = result.Parameters[0].Value;
                //Binding to the FQDN using the Service Account Credentials
                client.bind(serviceAccountUserName, serviceAccountPass, function (err) {
                    if (err) {
                        console.log("Bind Error" + err)
                    }
                    else {
                        console.log("no error in bind")
                        userId = userIdFromJde
                        //Passing the user id in filter to get attributes like mail,country,name & useraccountcontrol
                        var opts = {
                            filter: "(&(extensionAttribute4=" + userId + "))",
                            scope: "sub",
                            attributes: ['userAccountControl', 'mail', 'co', 'givenName']
                        };
                        //Searching the Ldap using the DN, opts json.
                        client.search(urlConstants.ldapDn, opts, function (searchErr, SearchRes) {
                            if (searchErr) {
                                console.log("Error in search " + searchErr)
                            } else {
                                console.log("this is response" + JSON.stringify(SearchRes))
                                var entries = []
                                SearchRes.on('searchEntry', function (entry) {
                                    //Capturing the response in an array
                                    entries.push(entry.object);
                                    return entries;
                                });

                                SearchRes.on('error', function (error) {
                                    console.error('error: ' + error.message);
                                });
                                SearchRes.on('end', function (searchResult) {
                                    console.log("entries" + JSON.stringify(entries))
                                    console.log('status: ' + searchResult);
                                    //Unbinding and destroying the connection
                                    client.unbind((unbindError) => {
                                        if (unbindError) {
                                            console.log("error in unbinding")
                                        }
                                        else {
                                            console.log("unbind successful")
                                        }
                                    });
                                    client.destroy();
                                    resolve(entries);
                                });
                            }
                        });
                    }
                });
            }, function (err) {
                console.log("We have the aws params getting error");
                console.log(err);
            }) // Adding the promise end
        }

        catch (e) {
            console.log(e);
            reject();
        }
    })
}
// Function to trigger Email
exports.triggerMail = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    sessionAttributes.serviceNowTriggred = 'false';
    var accessKeyIdValue, secretAccessKeyValue, sesConfig;
    // Get The Access key & Secret Key from AWS parameter store to  pass it in SES config
    try {
        var result = await awsParamStore.getParameters(['KeyId', 'accessKey'], { region: 'eu-west-1' })
        console.log("result is", result)
        if (result) {
            accessKeyIdValue = result.Parameters[0].Value;
            secretAccessKeyValue = result.Parameters[1].Value;
            sesConfig = {
                apiVersion: '2010-12-01',
                accessKeyId: accessKeyIdValue,
                secretAccessKey: secretAccessKeyValue,
                region: "eu-west-1"
            }

        }
        console.log("this is access key", accessKeyIdValue)
        console.log("this is secret key", secretAccessKeyValue)
        // Define the values to be passed to service Now
        var caller = 'VWT_caller: ' + sessionAttributes.userMail;
        var module = 'VWT_business_service: ' + sessionAttributes.serviceNowCategory
        var model = 'VWT_latis_rollout: ' + sessionAttributes.rollOut
        var urgency = 'VWT_urgency: ' + sessionAttributes.urgency
        var category = 'VWT_category: ' + sessionAttributes.category
        var message = sessionAttributes.description;
        var shortDesc = sessionAttributes.shortDesc;
        if (sessionAttributes.SourceCode !== "en") {
            var ReceivedMessages = message.split("+")
            // Split the Original and Translated Text to be sent to Service Now Description
            message = "Original Text : " + ReceivedMessages[0] + "<br>" + "Translated Text : " + ReceivedMessages[1];
        }
        var description = 'VWT_description:' + message
        var params = {
            Destination: { /* required */
                ToAddresses: [
                    // 'veglobaltest@service-now.com',
                    'yashraj.shaw.ext@veolia.com',
                    'monish.chandan-external@veolia.com',
                    'jailesh.mishra.ext@veolia.com'
                ]
            },
            Source: Constants.snowEmailFrom, /* required */
            Message: {
                Body: {
                    Html: {
                        Charset: "UTF-8",
                        Data: caller + "<br>" + module + "<br>" + model + "<br>" + urgency + "<br>" + category + "<br>" + description
                    }
                },
                Subject: {
                    Charset: 'UTF-8',
                    Data: '[LATIS Chatbot]' + " " + shortDesc
                }
            }
        };
        sessionAttributes.desc = null;
        sessionAttributes.incidentDescription = null;
        sessionAttributes.serviceNowCategory = null;
        sessionAttributes.serviceNowFlow = null;

        var sesObj = new AWS.SES(sesConfig)
        var sendPromise = await sesObj.sendEmail(params).promise()
        if (sendPromise) {
            console.log("Email sent")
            return true;
        } else {
            errorMessages.generalError(intentRequest, callback)

        }
    }
    catch (error) {
        console.log("this is err in service now ticket creation", error)
        errorMessages.generalError(intentRequest, callback)
    }

}

exports.getCredentials = async function (intentRequest, callback) {
    var chatbotUserId,chatbotPassword,encryptKey;
    var result = await awsParamStore.getParameters(['readOnlyUserId', 'readOnlyPassword','privateKey'], { region: 'eu-west-1' })
    console.log("result is", result)
    if (result) {
        chatbotUserId = result.Parameters[2].Value;
        chatbotPassword = result.Parameters[1].Value;
        encryptKey = result.Parameters[0].Value;
        console.log("Credentials are",chatbotUserId, chatbotPassword,encryptKey)
        return {
            "userId": chatbotUserId,
            "password": chatbotPassword,
            "key":encryptKey
        }    
    }
    else
    {
        await errorMessages.generalError(intentRequest,callback)
    }
}



