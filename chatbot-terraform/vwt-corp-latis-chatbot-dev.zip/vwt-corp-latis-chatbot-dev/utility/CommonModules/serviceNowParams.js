'use strict'
//Importing functional modules
const errorMessages = require('./commonErrorMessages')
const commonResponse = require('./commonResponseMessages')
const processCalls = require('../LatisModules/processCalls')
const ServiceNowConstants = require('../LatisModules/Constants/serviceNowParams.json')
const Services = require('../LatisModules/services')
const DbCall=require('../LatisModules/dbUtils')
//Declaring the counter variables
var descriptionCount = 1;
var urgencyCount = 1;
var categoryCount = 1;
var rollOutCount=1
exports.validateDescription = async function (intentRequest, callback) {
    var intentName = intentRequest.currentIntent.name;
    var sessionAttributes = intentRequest.sessionAttributes;

    if (intentName === "LATIS_Random_Identifier" && !(intentRequest.inputTranscript.includes("+"))) {
        descriptionCount++
        //Prompt to type description for three times, Terminate if exceeds 3.
        if (descriptionCount > 3) {
            descriptionCount = 1;
            await errorMessages.exhaustAttempts(intentRequest, callback)
        }
        //If the prompt has not exceeded thrice, ask for description again
        else {
            console.log("in service now params")
            await commonResponse.incidentDescription(intentRequest, callback, descriptionCount);
        }
    }
    //Gets Executed when user types something logical in the description
    else {
        console.log("in service now params urgency is hit")
        sessionAttributes.serviceNowStage = 'urgency'
        sessionAttributes.description = intentRequest.inputTranscript;
        await commonResponse.serviceNowUrgency(intentRequest, callback, urgencyCount);
    }

}
exports.validateUrgency = async function (intentRequest, callback) {
    descriptionCount = 1;
    var sessionAttributes = intentRequest.sessionAttributes;
    var urgency = intentRequest.inputTranscript;
    //validate if the user has entered a valid urgency option
    var validUrgency = await Services.validateUrgency(ServiceNowConstants.urgency, urgency, intentRequest)
    if (validUrgency) {
        //if valid input then trigger the bot to ask for category
        sessionAttributes.serviceNowStage = 'category'
        await commonResponse.serviceNowCategory(intentRequest, callback);
    }
    else {
        urgencyCount++
        if (urgencyCount > 3) {
            urgencyCount = 1;
            await errorMessages.exhaustAttempts(intentRequest, callback)
        }
        else {
            await commonResponse.serviceNowUrgency(intentRequest, callback, urgencyCount)
        }
    }

}
exports.validateCategory = async function (intentRequest, callback) {
    urgencyCount = 1;
    var category = intentRequest.inputTranscript;
    //Validate if the user has selected a valid category
    var validCategory = await Services.validateCategory(ServiceNowConstants.category, category, intentRequest)
    if (validCategory) {
        await processCalls.fetchRollOut(intentRequest, callback);
    }
    else {
        categoryCount++
        //Exhaust if more than 3 attempts
        if (categoryCount > 3) {
            categoryCount = 1;
            await errorMessages.exhaustAttempts(intentRequest, callback)
        }
        else {
            await commonResponse.serviceNowCategory(intentRequest, callback, categoryCount);
        }
    }
}
exports.validateShortDesc = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;


    sessionAttributes.shortDesc = intentRequest.inputTranscript;
    await commonResponse.incidentDescription(intentRequest, callback, urgencyCount);

}
exports.validateRollouts = async function(intentRequest, callback){
    var sessionAttributes = intentRequest.sessionAttributes;
    let rollouts = sessionAttributes.RollOutFR.split(",");
    let userInput = sessionAttributes.userinput;
    if(rollOutCount>=3)
    {
        rollOutCount=1;
        await errorMessages.exhaustAttempts(intentRequest, callback)
    }
    else
    {
      if(rollouts.includes(userInput)){
        rollOutCount=1;
        sessionAttributes.rollOut = intentRequest.inputTranscript;
        await DbCall.updateRollOut(sessionAttributes.UserIdJde, intentRequest)
        await processCalls.sendMail(intentRequest, callback);
    }else{
        rollOutCount++
        await processCalls.fetchRollOut(intentRequest, callback);
        console.log("not valid roll out");
    }
}
    
}


