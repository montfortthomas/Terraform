'use strict';
// Importing Node Modules
const AWS = require("aws-sdk");
AWS.config.update({ region: "eu-west-1" });

// Importing Functional Modules
const Templates = require("../../CommonModules/helperFunctions"); //Use to declare helper functions
const Session = require("../session"); //use to declare the session variables
const commonFunction=require('../../CommonModules/commonFunctions');
const errorMessages=require('../../CommonModules/commonErrorMessages');
const dbCall=require('../dbUtils');

// Triggers the response for Help Modules
exports.modelHelpResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var translatedButtonText, translatedMenu,menuItems, menuItemsEn;
    var Btn = [], Btn1 = [];
    var message = "Please type your question or select one of the following modules:";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    const type = "Menu";
    const AppState = intentName;
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);
    try
    {
    // Fetch the values from the table
    const results = await dbCall.callMenuTable('Help', sessionAttributes.SourceCode);
    // Fetch it in english as well to be passed as a value for the button
    const resultsEn = await dbCall.callMenuTable('Help', 'en');
    if (results) {
        menuItems = results.Item.SubModule.L
        menuItemsEn = resultsEn.Item.SubModule.L
        for (var i = 0; i < menuItems.length; i++) {
            var menu = menuItems[i].M.SubModuleName.S
            var menuEn = menuItemsEn[i].M.SubModuleName.S
            if (i < 5) {
                Btn.push({
                    text: menu,
                    Value: menuEn,
                });
            }
            else {
                Btn1.push({
                    text: menu,
                    Value: menuEn,
                });
            }
        }
    }
    else {
        // Triggered when there is no custom translation in Table
        // Translates the english responses using AWS translate
        menuItems = resultsEn.Item.SubModule.L;
        var menuArr = [...new Set(menuItems.map(x => x.M.SubModuleName.S))]; //array of menu
        var menuStr = menuArr.toString(); //menu array to string
        menuStr = menuStr.toLowerCase().replace(/,/g, "/");
        if (sessionAttributes.SourceCode !== "en") {
            translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
            translatedMenu = translatedButtonText.split("/");
        }
        for (var j = 0; j < menuArr.length; j++) {
            if (j < 5) {
                Btn.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }
            else {
                Btn1.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }
        }
    }
    var ButtonData = Templates.getButtons(Btn);
    console.log(ButtonData);
    if (Btn1.length > 0) {
        var ButtonData1 = Templates.getButtons(Btn1);
        return Templates.getResponseCardTemplateOne(sessionAttributes,message,ButtonData,ButtonData1,callback);
    } else {
        return Templates.getResponseCardTemplateTwo(sessionAttributes,message,ButtonData,callback);
    }
}
catch(error)
{
    await errorMessages.generalError(intentRequest, callback)
}
};