const AWS = require("aws-sdk");
AWS.config.update({ region: "eu-west-1" });

// Importing the functional Modules
const services = require("../services");
const Templates = require("../../CommonModules/helperFunctions");
const Session = require("../session");
const DbCall = require('../dbUtils')
const Constants = require('../Constants/constants.json')
const CommonFunction = require('../../CommonModules/commonFunctions')
const ErrorMessgaes = require('../../CommonModules/commonErrorMessages')

// Triggered to fetch the english answer from the table
exports.getEnglishAnswer = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    const slots = intentRequest.currentIntent.slots;
    var intentName = intentRequest.currentIntent.name;
    var dbData, faqAnswer, answerFromDb, answerObj, title, filteredAnswer, AliasFromDB, documentLink, shortMessage, AppState, translatedAnswer;
    AppState = intentName;
    const type = "Response";
    sessionAttributes.Confirmation = "confirm";
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);

    try {
        // Get the Answer from the table
        shortMessage = "I think you mean"
        dbData = await DbCall.getAnswer(intentName)
        // Filter the answer on the basis of country
        faqAnswer = await services.filterAnswer(dbData.Items, sessionAttributes.country);
        if (faqAnswer.length > 0) {
            // Filter the answer on the basis of slots
            if (Object.keys(slots).length !== 0) {
                filteredAnswer = await services.filterSlots(faqAnswer, intentRequest);
                answerObj = filteredAnswer
            }
            else {
                answerObj = faqAnswer
            }
            answerFromDb = answerObj[0].Answer.S;
            translatedAnswer = answerFromDb;
            AliasFromDB = answerObj[0].Alias.S;
            if (sessionAttributes.userinput.trim() !== AliasFromDB) {
                answerFromDb = shortMessage + ": '" + AliasFromDB + " ?'^" + answerFromDb;
                sessionAttributes.hasUserTypedQuery = "false";
            }
            sessionAttributes.serviceNowCategory = answerObj[0].ServiceNowCategory.S;
            // If the translated response table has no answer then translate it using amazon translate
            if (sessionAttributes.SourceCode !== 'en') {
                      await this.getMachineTranslation(intentRequest,callback,translatedAnswer,AliasFromDB,shortMessage,answerObj)
            }
            else {
                if (!answerObj[0].Google_Document_Link.S) {

                    return Templates.getResponseTemplateFour(sessionAttributes, answerFromDb, callback);
                }
                else {
                    title = Constants.title;
                    documentLink = answerObj[0].Google_Document_Link.S
                    return Templates.getResponseCardTemplateThree(sessionAttributes, answerFromDb, documentLink, title, callback);
                }
            }
        }
        else {
            Session.setCurrentOutputType(sessionAttributes, null);
            return await ErrorMessgaes.modelFaqNotAcessible(intentRequest, callback);
        }
    }
    catch (e) {
        console.log("error is", e)
        await ErrorMessgaes.modelFaqNotAcessible(intentRequest, callback);
    }

}
exports.getMachineTranslation = async function (intentRequest,callback,answer,aliasFromDB,shortMessage,answerObj) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var documentLink;
    shortMessage = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, shortMessage);
    answer = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, answer);
    if (sessionAttributes.userinput.trim() !== aliasFromDB) {

        if (!sessionAttributes.translatedAliasFromDB) {
            aliasFromDB = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, aliasFromDB);
        }
        else {
            aliasFromDB = sessionAttributes.translatedAliasFromDB;
        }
        answer = shortMessage + ": '" + aliasFromDB + " ?'^" + answer;
        sessionAttributes.hasUserTypedQuery = "false";
    }

    if (!answerObj[0].Google_Document_Link.S) {
        return Templates.getResponseTemplateFour(sessionAttributes, answer, callback);
    }
    else {
        documentLink = answerObj[0].Google_Document_Link.S
        var title = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, Constants.title);
        return Templates.getResponseCardTemplateThree(sessionAttributes, answer, documentLink, title, callback);
    }
}