'use strict';
// Importing Node Modules
const AWS = require("aws-sdk");

// Import the functional Modules
const Services = require("../services");
const Templates = require("../../CommonModules/helperFunctions"); 
const Session = require("../session"); 
const commonFunction=require('../../CommonModules/commonFunctions');
const errorMessages=require('../../CommonModules/commonErrorMessages');
const dbCall=require('../dbUtils');

// Configure the AWS parameter
AWS.config.update({ region: "eu-west-1" });

// Function to fetch and display the sub modules from the table
exports.modelSubModules = async function (intentRequest, callback) {
    var translatedButtonText;
    const type = "Menu";
    var menuItems, menuItemsEn;
    var Btn = [], Btn1 = [];
    // Bot Configurations
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    var currentSlot = intentRequest.currentIntent.slots;
    const AppState = intentName;
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);

    // Identify the Module Name
    var module = currentSlot.HelpMenu;
    var message = "Please select from below options";
    if (sessionAttributes.SourceCode !== "en") {
        message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    
    try
    {
    // DB call to fetch the menus on the basis of Language
    const results = await dbCall.callMenuTable(module, sessionAttributes.SourceCode);
    // Fetch it in english as well to be passed as a value for the button
    const resultsEn = await dbCall.callMenuTable(module, 'en');
    if (results) {
        // Run a filter to get the country specific menu
        menuItems = await Services.countrySpecificMenu(results.Item.SubModule.L, sessionAttributes);
        menuItemsEn = await Services.countrySpecificMenu(resultsEn.Item.SubModule.L, sessionAttributes);
        if (menuItems.length > 0) {
            for (var i = 0; i < menuItems.length; i++) {
                var menu = menuItems[i].M.SubModuleName.S
                var menuEn = menuItemsEn[i].M.SubModuleName.S
                if (i < 5) {
                    Btn.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
                else {
                    Btn1.push({
                        text: menu,
                        Value: menuEn,
                    });
                }
            }
        } else {
            Session.setCurrentOutputType(sessionAttributes, null);
            return await errorMessages.modelFaqNotAcessible(intentRequest, callback);
        }
    }
    else {
        menuItems = await Services.countrySpecificMenu(resultsEn.Item.SubModule.L, sessionAttributes);
        var menuArr = [...new Set(menuItems.map(x => x.M.SubModuleName.S))]; //array of menu
        var menuStr = menuArr.toString(); //menu array to string
        menuStr = menuStr.toLowerCase().replace(/,/g, "/");
        var translatedMenu;
        if (sessionAttributes.SourceCode !== "en") {
            translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
            console.log("translated string", translatedButtonText);
            translatedMenu = translatedButtonText.split("/");
        }
        for (var j = 0; j < menuArr.length; j++) {
            if (j < 5) {
                Btn.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }
            else {
                Btn1.push({
                    text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                    Value: menuArr[j],
                });
            }
        }
    }
    var ButtonData = Templates.getButtons(Btn);
    console.log(ButtonData);
    if (Btn1.length > 0) {
        var ButtonData1 = Templates.getButtons(Btn1);
        return Templates.getResponseCardTemplateOne(sessionAttributes,message,ButtonData,ButtonData1,callback);
    } else {
        return Templates.getResponseCardTemplateTwo(sessionAttributes,message,ButtonData,callback);
    }
    }
    catch (error)
    {
        await errorMessages.generalError(intentRequest, callback)
    }
};