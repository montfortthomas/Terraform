'use strict';
// Import Node Modules
const AWS = require("aws-sdk");
AWS.config.update({ region: "eu-west-1" });

// Import Functional Modules
const services = require("../services"); 
const Templates = require("../../CommonModules/helperFunctions"); 
const Session = require("../session"); 
const DbCall = require('../dbUtils')
const CommonFunction = require('../../CommonModules/commonFunctions')
const ErrorMessgaes = require('../../CommonModules/commonErrorMessages')
const EnglishAnswer = require('./getEnglishAnswer')
const Constants = require('../Constants/constants.json')

// This function will be executed to fetch the answer in any other language
exports.getOtherLangAnswer = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    const slots = intentRequest.currentIntent.slots;
    var intentName = intentRequest.currentIntent.name;
    var answerObj, title, filteredAnswer,documentLink, translatedAnswer,filteredTranslatedAnswer,translatedAnswerArr, AppState,englishAliasFromDb;
    AppState = intentName;
    const type = "Response";
    sessionAttributes.Confirmation = "confirm";
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);
    try {
        // Fetch the answer from the translated table
        translatedAnswerArr = await DbCall.callTranslateTable(intentName, sessionAttributes.SourceCode);
        // Filter the answer on the basis of Country
        filteredTranslatedAnswer = await services.filterAnswer(translatedAnswerArr.Items, sessionAttributes.country);
        if (filteredTranslatedAnswer.length > 0) {
            // Filter the answer on the basis of Slots
            if (Object.keys(slots).length !== 0) {
                filteredAnswer = await services.filterSlots(filteredTranslatedAnswer, intentRequest);
                answerObj = filteredAnswer
            }
            else {
                answerObj = filteredTranslatedAnswer;
            }
            
            translatedAnswer = answerObj[0].Answer.S
            sessionAttributes.translatedAliasFromDB=answerObj[0].Alias ? answerObj[0].Alias.S : null
            englishAliasFromDb=answerObj[0].EnglishAlias.S
            sessionAttributes.serviceNowCategory = answerObj[0].ServiceNowCategory ? answerObj[0].ServiceNowCategory.S : null
            // If Answer exists in DB
            if (translatedAnswer) {
                console.log("in translated answer");
                console.log("this is user input button",sessionAttributes.userinput)
                console.log("this is enlish Alias from DB",englishAliasFromDb);
                if (sessionAttributes.userinput.trim() !== englishAliasFromDb) {
                    var shortMessage = "I think you mean"
                    if (sessionAttributes.SourceCode !== "en") {
                        shortMessage = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, shortMessage);
                    }
                    translatedAnswer = shortMessage + ": '" + sessionAttributes.translatedAliasFromDB + "'?^" + translatedAnswer;
                    sessionAttributes.hasUserTypedQuery = "false";
                }
                // If the Google document link exists with the answer
                if (answerObj[0].Google_Document_Link) {
                    title = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, Constants.title)
                    documentLink = answerObj[0].Google_Document_Link.S
                    return Templates.getResponseCardTemplateThree(sessionAttributes, translatedAnswer, documentLink, title, callback);
                }
                else {
                    return Templates.getResponseTemplateFour(sessionAttributes, translatedAnswer, callback);
                }
            }
            // If the answer does not exist in translated table then fetch english answer
            else {
                return await EnglishAnswer.getEnglishAnswer(intentRequest, callback)
            }

        }
        else {
            Session.setCurrentOutputType(sessionAttributes, null);
            return await ErrorMessgaes.modelFaqNotAcessible(intentRequest, callback);
        }
    }
    catch (e) {
        console.log("error is", e)
        await ErrorMessgaes.modelFaqNotAcessible(intentRequest, callback);
    }


}