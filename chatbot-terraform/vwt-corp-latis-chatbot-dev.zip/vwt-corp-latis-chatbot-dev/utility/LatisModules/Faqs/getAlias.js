'use strict';
// Import Node Modules
const AWS = require("aws-sdk");
AWS.config.update({ region: "eu-west-1" });
const DbCall = require('../dbUtils');
// Import Functional Modules

const Services = require("../services");
const Templates = require("../../CommonModules/helperFunctions");
const Session = require("../session");
const commonFunction = require('../../CommonModules/commonFunctions')
const errorMessages = require('../../CommonModules/commonErrorMessages')
const dbCall = require('../dbUtils');
const timeInput = require('../GuidedResolution/TimeEntry/userInput')
const intentNames=require('../Constants/aliasIntentNames.json')
const cafInput=require('../GuidedResolution/CAF/userInput');
const salesUpdateInput=require('../GuidedResolution/SalesUpdate/userInput')
// Fetch the Aliases for a sub module
exports.modelFetchAlias = async function (intentRequest, callback) {
    var translatedButtonText, translatedMenu, domain, module, menuItems, menuItemsEn;
    const type = "Menu";
    var Btn = [], Btn1 = [];
    // Bot Configurations
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    const AppState = intentName;
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);

    // Identify the Module Name after splitting the intent name

    module=intentName;
    var res = module.split("_");
    domain = res[1];
    try {
        var message = "Please select from below options";
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunction.modeltranslation(sessionAttributes.SourceCode, message);
        }
        // Fetch the translated and english results from the table
        const results = await dbCall.callMenuTable(domain, sessionAttributes.SourceCode);
        // Fetch it in english as well to be passed as a value for the button
        const resultsEn = await dbCall.callMenuTable(domain, 'en');
        if (results) {
            // Filter the menu on the basis of the country
            menuItems = await Services.countrySpecificMenu(results.Item.SubModule.L, sessionAttributes);
            menuItemsEn = await Services.countrySpecificMenu(resultsEn.Item.SubModule.L, sessionAttributes);
            if (menuItems.length > 0) {
                for (var i = 0; i < menuItems.length; i++) {
                    var menu = menuItems[i].M.SubModuleName.S
                    var menuEn = menuItemsEn[i].M.SubModuleName.S
                    if (i < 5) {
                        Btn.push({
                            text: menu,
                            Value: menuEn,
                        });
                    }
                    else {
                        Btn1.push({
                            text: menu,
                            Value: menuEn,
                        });
                    }
                }
            } else {
                Session.setCurrentOutputType(sessionAttributes, null);
                return await errorMessages.modelFaqNotAcessible(intentRequest, callback);
            }
        } else {
            menuItems = await Services.countrySpecificMenu(resultsEn.Item.SubModule.L, sessionAttributes);
            var menuArr = [...new Set(menuItems.map(x => x.M.SubModuleName.S))]; //array of menu
            var menuStr = menuArr.toString(); //menu array to string
            menuStr = menuStr.toLowerCase().replace(/,/g, "/");
            if (sessionAttributes.SourceCode !== "en") {
                translatedButtonText = await commonFunction.modeltranslation(sessionAttributes.SourceCode, menuStr);
                console.log("translated string", translatedButtonText);
                translatedMenu = translatedButtonText.split("/");
            }
            for (var j = 0; j < menuArr.length; j++) {
                if (j < 5) {
                    Btn.push({
                        text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                        Value: menuArr[j],
                    });
                }
                else {
                    Btn1.push({
                        text: translatedMenu[j] ? translatedMenu[j][0].toUpperCase() + translatedMenu[j].substring(1) : menuArr[j],
                        Value: menuArr[j],
                    });
                }
            }
        }
        var ButtonData = Templates.getButtons(Btn);
        console.log(ButtonData);
        if (Btn1.length > 0) {
            var ButtonData1 = Templates.getButtons(Btn1);
            return Templates.getResponseCardTemplateOne(sessionAttributes, message, ButtonData, ButtonData1, callback);
        } else {
            return Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
        }
    }
    catch (error) {
        await errorMessages.generalError(intentRequest, callback)
    }
};

exports.FetchCustomAliasResponse = async function (intentRequest, callback) {
    var intentName = intentRequest.currentIntent.name;
    var sessionAttributes=intentRequest.sessionAttributes
    sessionAttributes.previousIntent=null;
    switch(intentName){
        case intentNames.timeEntryHelp_intent :
        var timeEntryStage='TimeEntry';
        await timeInput.customTimeResponse(intentRequest, callback,timeEntryStage);
        break;
        case intentNames.timeIntegrationHelp_intent : 
        var timeIntegrationStage='TimeIntegration';
        await timeInput.customTimeResponse(intentRequest, callback,timeIntegrationStage);
        break;
        case intentNames.jobCostCAFRecalculation:await cafInput.cafResponse(intentRequest,callback);
        break;
        case intentNames.cafHelp_intent:await cafInput.cafResponse(intentRequest,callback);
        break;
        case intentNames.salesUpdateHelpIntent: await salesUpdateInput.customSalesResponse(intentRequest,callback);
        break;
        default: 
        await this.modelFetchAlias(intentRequest, callback);
        break;
    }
   
}
