'use strict';
//import the node modules
let request = require("request");
let util = require('util');
request = util.promisify(request);
const langConstant = require('../LatisModules/Constants/langCodes.json')
const serviceParams=require('../LatisModules/Constants/serviceRespParams.json')
// Filter to get the country specific menu
exports.countrySpecificMenu = async function (arrData, sessionAttributes) {
    // Filtering the modules
    arrData.forEach(function (obj) {
        if (obj.M.Country) {
            if (obj.M.Country.S.search(sessionAttributes.country) < 0) {
                delete obj.M;
            }
        }
    });
    var arr = arrData.filter(function (el) {
        return el.M !== undefined;
    });
    console.log("arrData ", arr);
    return arr;
}
// Filter the Answer Array on the basis of detected slots
exports.filterSlots = async function (answerArray, intentRequest) {
    console.log("answer array in services", answerArray);

    var slots = intentRequest.currentIntent.slots;
    slots = Object.values(slots)[0];
    console.log("slots value ", slots)
    var finalFaqAnswer = answerArray.filter(function (el) {
        return el.Slot.S === slots;
    });
    console.log("final answer", finalFaqAnswer);
    return finalFaqAnswer;
}
// Filter the answer on the basis of Country
exports.filterAnswer = async function (arrData, country) {
    // Filtering the modules
    console.log("this is arr data", arrData)
    for (var i = 0; i < arrData.length; i++) {
        if (arrData[i].Country) {
            if (arrData[i].Country.S.search(country) < 0) {
                delete arrData[i];
            }
        }
    }
    console.log("arr is ", arrData)
    var arr = arrData.filter(function (el) {
        return "Country" in el
    });
    if (arr.length > 0) {
        console.log("fin arr", arr)
        return arr;
    } else {
        var filtered = arrData.filter(function (el) {
            return el !== null;
        });
        console.log("filtered array", filtered)
        return filtered;
    }
}
// Validate the urgency selected by User in the Service Now Flow
exports.validateUrgency = async function (urgencyArr, urgency, intentRequest) {
    var sessionAttributes = intentRequest.sessionAttributes
    var urgencyStr, urgencyFlag
    urgencyStr = urgency.trim();
    urgencyStr = urgencyStr.charAt(0).toUpperCase() + urgencyStr.slice(1);
    urgencyFlag = false;
    urgencyArr.forEach(function (obj) {
        if (obj.name.search(urgencyStr) >= 0) {
            //Set the urgency value in session attributes
            sessionAttributes.urgency = obj.value;
            urgencyFlag = true;
        }
    });
    return urgencyFlag;
}
// Validate if a valid category is selected by the user
exports.validateCategory = async function (categoryArr, category, intentRequest) {
    var sessionAttributes = intentRequest.sessionAttributes
    var categoryFlag = false;
    categoryArr.forEach(function (obj) {
        if (obj.name.search(category) >= 0) {
            //Store the selected category value in session attributes
            sessionAttributes.category = obj.name;
            categoryFlag = true;
        }
    });
    return categoryFlag;
}
exports.orderDetailsFormat = async function (orderFormat) {
    var OrderNumber = orderFormat.split(/[ ,/-]+/)[0];
    var OrderType = orderFormat.split(/[ ,/-]+/)[1];
    var OrderCompany = orderFormat.split(/[ ,/-]+/)[2];
    var lineNumber = orderFormat.split(/[ ,/-]+/)[3];
    return {
        "OrderNumber": OrderNumber,
        "OrderType": OrderType,
        "OrderCompany": OrderCompany,
        "LineNumber": lineNumber
    }
}
exports.poFormat = async function (orderFormat) {
    var OrderNumber = orderFormat.split(/[ ,/-]+/)[0];
    var OrderType = orderFormat.split(/[ ,/-]+/)[1];
    var OrderCompany = orderFormat.split(/[ ,/-]+/)[2];
    return {
        "OrderNumber": OrderNumber,
        "OrderType": OrderType,
        "OrderCompany": OrderCompany
    }
}
exports.timeEntryFormat = async function (orderFormat) {
    var ProjectNumber = orderFormat.split(/[ ,/-]+/)[0];
    var AddressNumber = orderFormat.split(/[ ,/-]+/)[1];
    var Month = orderFormat.split(/[ ,/-]+/)[2];
    var inputDate = orderFormat.split(/[ ,/-]+/)[3];
    var Year = orderFormat.split(/[ ,/-]+/)[4];
    return {
        "ProjectNumber": ProjectNumber,
        "AddressNumber": AddressNumber,
        "WorkDate": Month + "/" + inputDate + "/" + Year
    }
}
exports.timeEntryServiceOrderFormat = async function (orderFormat) {
    console.log("the order format is triggered");
    console.log(orderFormat);
    var serviceOrderNumber = orderFormat.split(/[ ,/-]+/)[0];
    var serviceOrderType = orderFormat.split(/[ ,/-]+/)[1];
    console.log("the final number and orderType is...", serviceOrderNumber, serviceOrderType);
    return {
        "serviceOrderNumber": serviceOrderNumber,
        "serviceOrderType": serviceOrderType
    }
}

exports.cafInputFormat = async function (cafInput) {
    var projectNumber = cafInput.split(/[.,/-]+/)[0];
    var accountNumber = cafInput.split(/[.,/-]+/)[1];
    var subsidiary=cafInput.split(/[.,/-]+/)[2]
    return {
        "projectNumber": projectNumber,
        "accountNumber": accountNumber,
        "subsidiary":subsidiary
    }
}

exports.getJdeLang = async function (intentRequest, sessionLang) {
    var sessionAttributes = intentRequest.sessionAttributes
    var langArr = langConstant.langArr
    langArr.forEach(function (obj) {
        if (obj.langCode.search(sessionLang) >= 0) {
            //Set the urgency value in session attributes
            sessionAttributes.jdeLang = obj.jdeLangCode;
        }
    });
    console.log("this is jde lang in services.js", sessionAttributes.jdeLang)
    return true;
}

exports.poReceivingInput = async function (orderFormat) {
    var orderNumber, orderType, orderCompany,lineNumber
     orderNumber = orderFormat.split(/[ ,/-]+/)[0];
     orderType = orderFormat.split(/[ ,/-]+/)[1];
     orderCompany = orderFormat.split(/[ ,/-]+/)[2];
     lineNumber=orderFormat.split(/[ ,/-]+/)[3];
    return {
        "orderNumber": orderNumber,
        "orderType": orderType,
        "orderCompany":orderCompany,
        "lineNumber":lineNumber
    }
}
exports.poReceiptFormat = async function (orderFormat) {
    var orderNumber = orderFormat.split(/[ ,/-]+/)[0];
    var orderType = orderFormat.split(/[ ,/-]+/)[1];
    var orderCompany = orderFormat.split(/[ ,/-]+/)[2];
    var voucherNumber = orderFormat.split(/[ ,/-]+/)[3];
    var voucherType  = orderFormat.split(/[ ,/-]+/)[4];
    var voucherCompany = orderFormat.split(/[ ,/-]+/)[5];
    var lineNumber= orderFormat.split(/[ ,/-]+/)[6];
    return {
        "OrderNumber": orderNumber,
        "OrderType": orderType,
        "OrderCompany": orderCompany,
        "VoucherNumber":voucherNumber,
        "VoucherType": voucherType,
        "VoucherCompany": voucherCompany,
        "LineNumber":lineNumber

    }
}
exports.batchErrorFormat = async function (orderFormat) {
    var batchNumber = orderFormat.split(/[ ,/-]+/)[0];
    var batchType = orderFormat.split(/[ ,/-]+/)[1];
    
    return {
        "BatchNumber": batchNumber,
        "BatchType": batchType
        
    }
}

exports.validateCaf = async function (intentRequest,callback,userInput) {
    var sessionAttributes = intentRequest.sessionAttributes
    var cafFlag = false;
    var cafArr=serviceParams.cafParams;
    cafArr.forEach(function (obj) {
        if (obj.name.search(userInput.toLowerCase().trim()) >= 0) {
            //Store the selected category value in session attributes
            sessionAttributes.cafRule = obj.value;
            cafFlag = true;
        }
    });
    return cafFlag;
}

exports.validateUserId = async function(sessionAttributes){
  let userId = sessionAttributes.UserIdJde;
  let regex = /^([A-Za-z0-9]){10}$/;
  if (regex.test(userId)){
    let subChar = userId.toString().substr(7, 3);
    if (subChar === "V9U" || subChar === "V9M" || subChar === "V9H") {
        console.log("From the Sercice user Validation make a query now")
      return true;
  }else{
      console.log("Sub stirng not matched from Service user validation");
      return false;
  }
}else{
    console.log("Patter not matched user validation");
    return false;
}
}
exports.validateTimeEntryInput = async function (timeEntryInput) {
    var projectNumber = timeEntryInput.split(/[ ,/-]+/)[0];
    var addressNumber = timeEntryInput.split(/[ ,/-]+/)[1];
    if( projectNumber && addressNumber){
        if(projectNumber.length<=12 && addressNumber.length<=12)
    {
        console.log("this is project number length",projectNumber.length)
        console.log("this is address number length",addressNumber.length)
        return true;
    }
    else
    {
        console.log("this is project number length",projectNumber.length)
        console.log("this is address number length",addressNumber.length)
        return false
    }
    }else{
        return false;
    }
  
}
exports.validateCafInput = async function (cafInput) {
    console.log("CAF validation .....")
    var projectNumber = cafInput.split(/[.,/-]+/)[0];
    var objectAccount = cafInput.split(/[.,/-]+/)[1];
    var subsidary = cafInput.split(/[.,/-]+/)[2];
    if(projectNumber && objectAccount && subsidary ){
        if(projectNumber.length<=12 && objectAccount.length<=6  && subsidary.length<=8){
            console.log("this is project number length",projectNumber.length)
            console.log("this is object account length",objectAccount.length)
            console.log("this is subsidary length",subsidary.length)
            return true;
        }
        else
        {
            console.log("this is project number length",projectNumber.length)
            console.log("this is object account length",objectAccount.length)
            console.log("this is subsidary length",subsidary.length)
            return false;
        }
    }else{
        return false;
    }
  
}

exports.validatePoPrintInput = async function (poPrintInput) {
    console.log("Po Print validation .....")
    var orderNumber = poPrintInput.split(/[ ,/-]+/)[0];
    var orderType = poPrintInput.split(/[ ,/-]+/)[1];
    var orderCompany = poPrintInput.split(/[ ,/-]+/)[2]
    if(orderNumber && orderType && orderCompany){
        if(orderNumber.length<=8 && orderType.length<=2  && orderCompany.length<=5)
        {
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            return true;
        }
        else
        {
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            return false;
        }
    }else{
        console.log("the undefined values")
        console.log("this is orderNumber length",orderNumber)
        console.log("this is orderType length",orderType)
        console.log("this is orderCompany length",orderCompany)
        return false;
    }

}

exports.validatePoReceiving = async function (poReceivingInput) {
    console.log("PoReceiving  validation .....")
    var orderNumber = poReceivingInput.split(/[ ,/-]+/)[0];
    var orderType = poReceivingInput.split(/[ ,/-]+/)[1];
    var orderCompany = poReceivingInput.split(/[ ,/-]+/)[2];
    var lineNumber = poReceivingInput.split(/[ ,/-]+/)[3]
    if(orderNumber && orderType && orderCompany && lineNumber){
        if(orderNumber.length<=8 && orderType.length<=2  && orderCompany.length<=5 && lineNumber.length <=2){
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            console.log("this is lineNumber length",lineNumber.length)
            return true;
        }
        else
        {
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            console.log("this is lineNumber length",lineNumber.length)
            return false;
        }
    }else{
        console.log("undefined values ...")
        console.log("this is orderNumber length",orderNumber)
        console.log("this is orderType length",orderType)
        console.log("this is orderCompany length",orderCompany)
        console.log("this is lineNumber length",lineNumber)
        return false;
    }
 
}

exports.validatesalesUpdate = async function (salesUpdateInput) {
    console.log("sale supdate  validation .....")
    var orderNumber = salesUpdateInput.split(/[ ,/-]+/)[0];
    var orderType = salesUpdateInput.split(/[ ,/-]+/)[1];
    var orderCompany = salesUpdateInput.split(/[ ,/-]+/)[2]
    if(orderNumber && orderType && orderCompany){
        console.log("the values are ...")
        if(orderNumber.length<=8 && orderType.length<=2  && orderCompany.length<=5)
        {
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            return true;
        }
        else
        {
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            return false;
        }
    }else{
        console.log("there are undefined values");
        console.log("this is orderNumber length",orderNumber)
        console.log("this is orderType length",orderType)
        console.log("this is orderCompany length",orderCompany)
        return false;
    }

}

exports.validateshipConfirmation = async function (shipConfirmationInput) {
    console.log("ship confirmation validation .....")
    var orderNumber = shipConfirmationInput.split(/[ ,/-]+/)[0];
    var orderType = shipConfirmationInput.split(/[ ,/-]+/)[1];
    var lineNumber = shipConfirmationInput.split(/[ ,/-]+/)[2]
    if(orderNumber && orderType && lineNumber){
        console.log("Value are .....")
        if(orderNumber.length<=8 && orderType.length<=2  && lineNumber.length<=7){
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is lineNumber length",lineNumber.length)
            return true;
        }else{
            console.log("length does not match");
            console.log("this is orderNumber length",orderNumber.length)
            console.log("this is orderType length",orderType.length)
            console.log("this is orderCompany length",orderCompany.length)
            return false;
        }
    }else{
        console.log("there are undefined values");
        console.log("this is orderNumber length",orderNumber)
        console.log("this is orderType length",orderType)
        console.log("this is lineNumber length",lineNumber)

        return false;
    }
}

exports.validateTimeEntryServiceOrder = async function (serviceOrderInput) {
    console.log("time Entry service order .....")
    var orderNumber = serviceOrderInput.split(/[ ,/-]+/)[0];
    var orderType = serviceOrderInput.split(/[ ,/-]+/)[1];
    if(orderNumber && orderType){
        console.log("Value are .....")
        if(orderNumber.length<=8 && orderType.length<=2)
            return true;
    }else{
        return false
    }
   
}