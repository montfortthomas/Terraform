'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const Services = require('../../services')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const commonResponseMessages = require('../../../CommonModules/commonResponseMessages')
const serviceParams = require('../../Constants/serviceRespParams.json');
const crypto = require('crypto');

exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
        var userId = credentials.userId;
        var password = credentials.password;
        var privateKey = credentials.key;
        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        console.log("buff", bufdata);
        var sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        var signature = sign.toString('base64');
        console.log("signature", signature);
        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': auth,
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature': signature
            },
        };
        let data = await request(options);
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    console.log("this is jde lang", sessionAttributes.jdeLang)
    var response, message;
    var userInput = intentRequest.inputTranscript;
    var jsonInput = {
        "Project Number": sessionAttributes.projectNumber,
        "Object Account": sessionAttributes.objectAccount,
        "Subsidiary": sessionAttributes.subsidiary,
        "Rule": sessionAttributes.cafRule,
        "Language": sessionAttributes.jdeLang,
        "UseCase": "U02",
        "User ID":sessionAttributes.UserIdJde,
        "Role": sessionAttributes.Role
    }
    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.cafIssue, intentRequest, callback);
        console.log("this is the service response", body);
        message = "Below are the issues which I found for your CAF issue";
        if (body.Result === false) {
            message = body.Z_szErrorDesEn_U00_07_01_DL011
            message = decodeURIComponent(JSON.parse('"' + message.replace(/\"/g, '\\"') + '"'))
            if (sessionAttributes.SourceCode !== 'en') {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            }
            sessionAttributes.previousIntent = null;
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.cafIssue, "error");
            if (response.resEn.length === 0) {
                response = await this.getResMessages(intentRequest, callback, body, serviceParams.cafIssue, "success");
                if (response.resEn.length === 0) {
                    message = "No issue found during the initial investigation. Do you want me to log a ticket to investigate further";
                }
            }
            if (sessionAttributes.SourceCode !== "en") {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
                message = message + "\n" + response.resOt.toString().replace(/,/g, '');
            } else {
                message = message + "\n" + response.resEn.toString().replace(/,/g, '');
            }


            var type = "Response";
            Session.setCurrentOutputType(sessionAttributes, type);
            sessionAttributes.Confirmation = "confirm";
            sessionAttributes.previousIntent = null;
            sessionAttributes.Confirmation = "guidedResolutionSnow";
            sessionAttributes.serviceNowFlow = "guidedResolution";
            sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Finance-FIN";
            sessionAttributes.shortDesc = "CAF issue for " + sessionAttributes.cafUserInput + "/" + userInput + " (Project Number/Object Account/Subsidiary)";
            sessionAttributes.description = message;
            if (sessionAttributes.SourceCode !== "en") {
                var translatedMessage = await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description = message + "+" + translatedMessage
            }
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    } catch (error) {
        console.log("this is error in web service response", error);
        await errorMessages.generalError(intentRequest, callback);
    }

}

exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    let resEn = [];
    let resOt = [];
    let startIndex, endIndex, startKeyYn, startKeyEn, startKeyOt, bodyDataVar,endKey,endKeyYn;
    var sessionAttributes = intentRequest.sessionAttributes;
    if (msgType === "success") {
        console.log("in success")
        console.log("this is caf rule", sessionAttributes.cafRule)
        if (sessionAttributes.cafRule === '1') {
            startIndex = serviceResp.amStartIndex;
            endIndex = serviceResp.amEndIndex;
            startKeyYn = serviceResp.amStartKeyYN
            startKeyEn = serviceResp.amstartKeyErrDescEn
            startKeyOt = serviceResp.amstartKeyErrDescOt
        }
        else if (sessionAttributes.cafRule === '2') {
            startIndex = serviceResp.eacStartIndex;
            endIndex = serviceResp.eacEndIndex;
            startKeyYn = serviceResp.eacStartKeyYN
            startKeyEn = serviceResp.eacstartKeyErrDescEn
            startKeyOt = serviceResp.eacstartKeyErrDescOt
        }
        else {
            startIndex = serviceResp.crStartIndex;
            endIndex = serviceResp.crEndIndex;
            startKeyYn = serviceResp.crStartKeyYN
            startKeyEn = serviceResp.crStartKeyErrDescEn
            startKeyOt = serviceResp.crStartKeyErrDescOt
        }

    } else {
       
            startIndex = 0;
            endIndex = 0;
        }
    
    console.log(msgType);
    if (startIndex !== 0) {
        for (let i = startIndex; i <= endIndex; i++) {
            let index = i > 9 ? "_" + i : "_0" + i;
            if (sessionAttributes.cafRule === '2' && index === "_05")
                break;
            if (sessionAttributes.cafRule === '3' && (index === "_03" || index === "_04"))
                break;
            console.log("this is index", index)
            let bodyDataYN = startKeyYn + index + serviceResp.eacEndKeyYN;
            console.log("this is body Data Yn", bodyDataYN);
            let bodyDataOt = startKeyOt + index + serviceResp.eacendKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            let bodyDataEn = startKeyEn + index + serviceResp.eacendKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);

            if (body[bodyDataYN] === "Y" || body[bodyDataYN] === "y") {
              body[bodyDataEn]= decodeURIComponent(JSON.parse('"' + body[bodyDataEn].replace(/\"/g, '\\"') + '"'))
                if (sessionAttributes.cafRule === '2') {
                    if (body.Z_mnVariable_U02_06_02_MATH01) {
                        bodyDataVar = body.Z_mnVariable_U02_06_02_MATH01
                        resEn.push("- " + body[bodyDataEn] + "\n" + bodyDataVar);
                    }
                    else {

                        resEn.push("- " + body[bodyDataEn] + "\n");
                    
                    }

                }
                else {
                    resEn.push("- " + body[bodyDataEn] + "\n");
                }
                if (sessionAttributes.SourceCode != "en") {
                    let otherLangMessage;
                    if (!body[bodyDataOt]) {
                        otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                    } else {
                        otherLangMessage = body[bodyDataOt];
                    }
                    otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                    if (sessionAttributes.cafRule === "2" && bodyDataVar) {
                        resOt.push("- " + otherLangMessage + "\n" + bodyDataVar + "\n");
                        bodyDataVar = null;

                    }
                    else {
                        resOt.push("- " + otherLangMessage + "\n");
                    }

                }
            }
        }
    }
    else {
        switch (sessionAttributes.cafRule) {
            case "1": startIndex = 5;
                endIndex = 6;
                startKeyYn = "Z_cErrorYN_U02_05";
                endKeyYn = "_EV01"
                startKeyEn = "Z_szErrorDescEn_U02_05"
                endKey = "_DL"
                startKeyOt = "Z_szErrorDescOt_U02_05"
                break;
            case "2": startIndex = 3;
                endIndex = 4;
                startKeyYn = "Z_cErrorYN_U02_06";
                endKeyYn = "_EV01"
                startKeyEn = "Z_szErrorDescEn_U02_06"
                endKey = "_DL"
                startKeyOt = "Z_szErrorDescOt_U02_06"
                break;
            case "3": 
                console.log("in caf rule 3 of switch")
                startIndex = 2;
                endIndex = 3;
                startKeyYn = "Z_cErrorYN_U2_07";
                endKeyYn = "_EV01"
                startKeyEn = "Z_szErrorDescEn_U02_07"
                endKey = "_DL"
                startKeyOt = "Z_szErrorDescOt_U02_07"
                break;
            default:
                break;

        }
        for (let i = startIndex; i <= endIndex; i++) {
            let index = i > 9 ? "_" + i : "_0" + i;
            let bodyDataYN = startKeyYn + index + endKeyYn;
            console.log("this is body Data Yn", bodyDataYN);
            let bodyDataOt = startKeyOt + index + endKey;
            console.log("this is body Data OT", bodyDataOt);
            let bodyDataEn = startKeyEn + index + endKey;
            console.log("this is body Data En", bodyDataEn);
            if (body[bodyDataYN] === "Y" || body[bodyDataYN] === "y") {
                body[bodyDataEn] = decodeURIComponent(JSON.parse('"' + body[bodyDataEn].replace(/\"/g, '\\"') + '"'))
                resEn.push("- " + body[bodyDataEn] + "\n");
                if (sessionAttributes.SourceCode != "en") {
                    let otherLangMessage;
                    if (!body[bodyDataOt]) {
                        otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                    } else {
                        otherLangMessage = body[bodyDataOt];
                    }
                    otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                    resOt.push("- " + otherLangMessage + "\n");
                }
            }
        }

    }

    console.log("this is res En", resEn);
    console.log("this is res Ot", resOt);
    console.log("this is res en length", resEn.length);
    return {
        resEn: resEn,
        resOt: resOt
    }
}


