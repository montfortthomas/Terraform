

exports.getService = async function (intentRequest, callback) {
    console.log("in the get service");
    console.log(intentRequest);
    
}