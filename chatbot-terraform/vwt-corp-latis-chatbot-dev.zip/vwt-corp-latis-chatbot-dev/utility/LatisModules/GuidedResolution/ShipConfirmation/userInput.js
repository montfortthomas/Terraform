const commonFunctions = require('../../../CommonModules/commonFunctions')
const Templates = require('../../../CommonModules/helperFunctions')
const Services = require('../../services');
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const webServiceCall=require('./service')
const intentNames=require('../../Constants/intentNames.json')
var count = 1;
exports.inputParameters = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, order;
    var pattern = "[0-9]{1,8}[/|,|-]([a-zA-Z0-9]){2}[/|,|-][a-zA-Z0-9]{1,5}[/|,|-][0-9]{1,7}"
    sessionAttributes.previousIntent = intentNames.shipConfirmGuidedResolution
    order = userInput.match(pattern);
    let validateInput= await Services.validateshipConfirmation(userInput)
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (order && validateInput) {
        count=1;
        await this.validateInput(intentRequest, callback, order)
    }
    else {
      
        if (count <=3) {
            count++
            sessionAttributes.currentCount = count;
            message = "Please enter your input in the below format\nOrder Number/Order Type/Order Company/Line Number (Ex: 93109687/SO/00931/1)"
            if(sessionAttributes.SourceCode!=="en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
    }
}
exports.validateInput = async function (intentRequest, callback, order) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var orderFormat, orderNumber, orderType, orderCompany, lineNumber;

    orderFormat = order[0];
    let orderData = await Services.orderDetailsFormat(orderFormat);
    orderNumber = orderData.OrderNumber;
    orderType = orderData.OrderType;
    orderCompany = orderData.OrderCompany;
    lineNumber = orderData.LineNumber
    sessionAttributes.orderNumber = orderNumber;
    sessionAttributes.orderType = orderType;
    sessionAttributes.orderCompany = orderCompany
    sessionAttributes.lineNumber = lineNumber
    sessionAttributes.currentCount = null;
   // message = "The order is" + "\n" + sessionAttributes.orderNumber + "\n" + sessionAttributes.orderType + "\n" + sessionAttributes.orderCompany + "\n" + sessionAttributes.lineNumber
    await webServiceCall.webServiceResponse(intentRequest,callback)
   // await Templates.getResponseTemplateFour(sessionAttributes, message, callback);

}