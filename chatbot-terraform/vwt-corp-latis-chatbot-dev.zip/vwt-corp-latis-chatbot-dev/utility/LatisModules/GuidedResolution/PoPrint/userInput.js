const getAlias = require('../../Faqs/getAlias');
const Templates = require('../../../CommonModules/helperFunctions');
const intentNames = require('../../Constants/intentNames.json')
const DbCall = require('../../dbUtils')
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const commonFunctions=require('../../../CommonModules/commonFunctions')
const Services=require('../../services')
const webServiceCall=require('./service')
var count=1;
exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, poPrintInput;
    sessionAttributes.previousIntent=intentNames.poPrintGuidedResolution;
    var pattern = "[0-9]{1,8}[/|,|-]([a-zA-Z0-9]){2}[/|,|-][a-zA-Z0-9]{1,5}"
    //date pattern is "[0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$"
    poPrintInput = userInput.match(pattern);
    var validateInput= await Services.validatePoPrintInput(userInput)
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (poPrintInput && validateInput) {
        count=1;
        await this.storeInput(intentRequest, callback, poPrintInput)
    }
    else {
        
        if (count <=3) {
            count++
            sessionAttributes.currentCount = count;
            message = "Please enter your input in the below format\nOrder Number/Order Type/Order Company"
            if(sessionAttributes.SourceCode!=="en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
        
    }
}
exports.storeInput= async function (intentRequest, callback, poPrintInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var poFormat, orderNumber, orderType, orderCompany, message;
    
    poFormat= poPrintInput[0];
    let userInput = await Services.poFormat(poFormat);
    orderNumber = userInput.OrderNumber;
    orderType = userInput.OrderType;
    orderCompany = userInput.OrderCompany;
    sessionAttributes.orderNumber = orderNumber;
    sessionAttributes.orderType = orderType;
    sessionAttributes.orderCompany = orderCompany;
    sessionAttributes.currentCount = null;
    await webServiceCall.webServiceResponse(intentRequest,callback)
    // await Templates.getResponseTemplateFour(sessionAttributes, message, callback);

}