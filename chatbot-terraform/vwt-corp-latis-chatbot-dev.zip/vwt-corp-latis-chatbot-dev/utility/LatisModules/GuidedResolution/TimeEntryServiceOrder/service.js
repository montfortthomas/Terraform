'use strict'
let request = require("request");
let util = require('util');
request = util.promisify(request);
const urls = require('../../Constants/Urls.json')
const errorMessages = require('../../../CommonModules/commonErrorMessages')
const Templates = require('../../../CommonModules/helperFunctions')
const Session = require('../../session')
const Services = require('../../services')
const commonFunctions = require('../../../CommonModules/commonFunctions')
const commonResponseMessages = require('../../../CommonModules/commonResponseMessages')
const serviceParams = require('../../Constants/serviceRespParams.json')
const crypto = require('crypto');
exports.callWebService = async function (jsonInput, url, intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userId,password,privateKey,sign,signature;
    console.log("session", sessionAttributes);
    try {
        let credentials = await commonFunctions.getCredentials(intentRequest, callback)
        userId = credentials.userId;
        password = credentials.password
        privateKey = credentials.key;
       
        console.log("the jsoninput", jsonInput);

        const bufdata = Buffer.from(JSON.stringify(jsonInput));
        sign = crypto.sign("RSA-SHA256", bufdata, privateKey);
        signature = sign.toString('base64');

        console.log("signature", signature);

        var auth = "Basic " + new Buffer.from(userId + ":" + password).toString("base64");
        var options = {
            url: url,
            method: 'POST',
            json: jsonInput,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': auth,
                'jde-AIS-Auth-Environment': sessionAttributes.Environment,
                'Signature':signature
            },
        };
        let data = await request(options);
        if (data.statusCode === 200) {
            console.log("this is data", JSON.stringify(data))
            return data.body;
        }
        else {
            console.log("this is data", JSON.stringify(data))
            await errorMessages.generalError(intentRequest, callback)
        }
    } catch (error) {
        console.log("this is error in call jde", error)
        await errorMessages.generalError(intentRequest, callback)
    }
}
exports.webServiceResponse = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    await Services.getJdeLang(intentRequest, sessionAttributes.SourceCode)
    console.log("this is jde lang", sessionAttributes.jdeLang)
    var response, message;
    var userInput = intentRequest.inputTranscript;
    var jsonInput =   {
        "UserID": "FRCHAN0V9H",
        "Role": "R_RLW9805S",
        "UsecaseID": "",
        "BatchNo": "",
        "BatchTy": "",
        "FromandThruValue": "",
        "LanguagePreference": sessionAttributes.jdeLang,
        "OrderNo": sessionAttributes.serviceOrderNumber,
        "OrderType": sessionAttributes.serviceOrderType,
        "Company": ""
      }
    console.log(jsonInput);
    try {
        let body = await this.callWebService(jsonInput, urls.timeEntryServiceOrder, intentRequest, callback);
        console.log("this is the service response", body);
        message = "Below are the issues which I found for your Time Entry";
        if (body.Result === false) {
            await errorMessages.dataNotAuthorised(intentRequest, callback)
        }
        else
        {
        response = await this.getResMessages(intentRequest, callback, body, serviceParams.timeEntryServiceOrder, "error");
        if (response.resEn.length === 0) {
            response = await this.getResMessages(intentRequest, callback, body, serviceParams.timeEntryServiceOrder, "success");
            if (response.resEn.length === 0) {
                message = "No issue found during the initial investigation";
            }
        }
        if (sessionAttributes.SourceCode !== "en") {
            message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message);
            message = message + "\n" + response.resOt.toString().replace(/,/g, '');
        } else {
            message = message + "\n" + response.resEn.toString().replace(/,/g, '');
        }


        var type = "Response";
        Session.setCurrentOutputType(sessionAttributes, type);
        sessionAttributes.Confirmation = "confirm";
        sessionAttributes.previousIntent = null;
        sessionAttributes.Confirmation = "guidedResolutionSnow";
        sessionAttributes.serviceNowFlow = "guidedResolution";
        sessionAttributes.serviceNowCategory = "VWT-Latis - Func-Finance-TE";
        sessionAttributes.shortDesc = "Time Entry Service Order Error for " + userInput +" (Project Number /Address Number/Work Date)"
        sessionAttributes.description = message;
        if(sessionAttributes.SourceCode !== "en")
            {
                var translatedMessage= await commonFunctions.modeltranslation("en", message);
                sessionAttributes.description=message+"+"+translatedMessage
            }
        await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    } catch (error) {
        console.log("this is error in web service response", error);
        await errorMessages.generalError(intentRequest, callback);
    }

}

exports.getResMessages = async function (intentRequest, callback, body, serviceResp, msgType) {
    let resEn = [];
    let resOt = [];
    let startIndex, endIndex, bodyDataVar;
try{
    if (msgType === "success") {
        startIndex = serviceResp.sStartIndex;
        endIndex = serviceResp.sEndIndex;
    } else {
        startIndex = 0;
    }
    console.log(msgType);
    var sessionAttributes = intentRequest.sessionAttributes;
    if (startIndex !== 0) {
        for (let i = startIndex; i <= endIndex; i++) {
            let index = i > 9 ? "_" + i : "_0" + i;
            console.log("this is index", index)
            let bodyDataYN = serviceResp.startKeyYN + index + serviceResp.endKeyYN;
            console.log("this is body Data Yn", bodyDataYN);
            let bodyDataOt = serviceResp.startKeyErrDescOt + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data OT", bodyDataOt);
            let bodyDataEn = serviceResp.startKeyErrDescEn + index + serviceResp.endKeyErrDesc;
            console.log("this is body Data En", bodyDataEn);

            if (body[bodyDataYN].toUpperCase() === "Y") {
                resEn.push("- " + body[bodyDataEn] + "\n");
            }
            if (body[bodyDataYN].toUpperCase() === "Y" && sessionAttributes.SourceCode !== "en") {
                let otherLangMessage;
                if (!body[bodyDataOt]) {
                    otherLangMessage = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, body[bodyDataEn]);
                } else {
                    otherLangMessage = body[bodyDataOt];
                }
                console.log("this is other language message", otherLangMessage)
                console.log("this is bodyDataVar", body[bodyDataVar])
                
               
                otherLangMessage = decodeURIComponent(JSON.parse('"' + otherLangMessage.replace(/\"/g, '\\"') + '"'))
                resOt.push("- " + otherLangMessage + "\n");
            }
        }
    }
    else {
        if (body.Z_cErrorYN_U10_EV01.toUpperCase() === "Y") { 
            resEn ="-"+ body.Z_szErrorDescEn_U10_DL011
            resEn=decodeURIComponent(JSON.parse('"' + resEn.replace(/\"/g, '\\"') + '"'))
            resOt = body.Z_szErrorDescOt_U10_DL011;
            if (!resOt)
            {
                resOt = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, resEn);
                resOt = decodeURIComponent(JSON.parse('"' + resOt.replace(/\"/g, '\\"') + '"'))
            }
        }
    }
    console.log("this is res En", resEn);
    console.log("this is res Ot", resOt);
    console.log("this is res en length", resEn.length);
    return {
        resEn: resEn,
        resOt: resOt
    }
 }
 catch (error) {
    console.log("this is error in  getMessage response", error)
    await errorMessages.generalError(intentRequest, callback)
    }
}

