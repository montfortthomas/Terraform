const Templates = require('../../../CommonModules/helperFunctions');
const commonFunctions=require('../../../CommonModules/commonFunctions');
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const intentNames=require('../../Constants/intentNames.json');
const Services=require('../../services');
const webServiceCall=require('./service');
var count = 1;

exports.validateInput = async function (intentRequest, callback) {
    console.log("validate the user input of time entry Service order error");
    console.log(intentRequest);
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript
    var pattern = "([0-9]){1,8}[/|,|-][a-zA-Z]{2}"
    var Input = userInput.match(pattern);
    let validateInput= await Services.timeEntryServiceOrder(userInput)
    sessionAttributes.previousIntent = intentNames.timeEntryServiceOrderResolution;
    console.log("current session count",sessionAttributes.currentCount);
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (Input && validateInput) {
        count = 1;
        this.storeInput(intentRequest, Input, callback);
    } else {
        console.log("count", count);
        if (count <= 3) {
            count++;
            sessionAttributes.currentCount = count;
            console.log("message is taken");
            var message = "Please enter your input in the below format \n Service Order Number / Order Type (Ex:1068319/SX)"
            if (sessionAttributes.SourceCode !== 'en') {
                message = await commonFunctions.modeltranslation(sessionAttributes.SourceCode, message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
            console.log("came back");
        }
        
    }

}

exports.storeInput = async function (intentRequest, Input, callback) {
    console.log("the store input is triggred from TESOError");
    var sessionAttributes = intentRequest.sessionAttributes;
    let inputFormat = Input[0];
    let userInput = await Services.timeEntryServiceOrderFormat(inputFormat);
    sessionAttributes.serviceOrderNumber = userInput.serviceOrderNumber;
    sessionAttributes.serviceOrderType = userInput.serviceOrderType;
    sessionAttributes.currentCount = null;
    await webServiceCall.webServiceResponse(intentRequest,callback)
}