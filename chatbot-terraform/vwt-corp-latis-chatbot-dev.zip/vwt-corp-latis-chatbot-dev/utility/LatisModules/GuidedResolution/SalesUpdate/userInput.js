const getAlias = require('../../Faqs/getAlias');
const Templates = require('../../../CommonModules/helperFunctions');
const intentNames = require('../../Constants/intentNames.json');
const DbCall = require('../../dbUtils')
const errorMessages=require('../../../CommonModules/commonErrorMessages')
const commonFunctions=require('../../../CommonModules/commonFunctions')
const Services=require('../../services')
const webServiceCall=require('./service')
var count=1;   
exports.validateInput = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var userInput = intentRequest.inputTranscript;
    var message, orderInput;
    sessionAttributes.previousIntent = intentNames.salesUpdateGuidedResolution;
    var pattern = "[0-9]{1,8}[/|,|-]([a-zA-Z0-9]){2}[/|,|-][a-zA-Z0-9]{1,5}"
    orderInput = userInput.match(pattern);
    let validateInput= await Services.validatesalesUpdate(userInput)
    if(!sessionAttributes.currentCount){
        count = 1;
    }
    if (orderInput && validateInput) {
        count=1;
        await this.storeInput(intentRequest, callback, orderInput)
    }
    else {
        console.log("not valid input for sales");
        if (count <=3) {
            count++
            sessionAttributes.currentCount = count;
            message = "Please enter your input in the below format\n Order Number /Orde Type/Order Company (Ex:20012205/SO/01103)"
            if(sessionAttributes.SourceCode!== "en")
            {
                message=await commonFunctions.modeltranslation(sessionAttributes.SourceCode,message)
            }
            sessionAttributes.OutputType = "shortDescription";
            await Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        else {
            count = 1;
            sessionAttributes.currentCount = null;
            errorMessages.exhaustAttempts(intentRequest, callback)
        }
        
    }
}
exports.storeInput= async function (intentRequest, callback, orderInput) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var inputFormat;
    inputFormat= orderInput[0];
    let userInput = await Services.orderDetailsFormat(inputFormat);
    sessionAttributes.orderNumber = userInput.OrderNumber;
    sessionAttributes.orderType = userInput.OrderType;
    sessionAttributes.orderCompany= userInput.OrderCompany;
    sessionAttributes.currentCount = null;
    await webServiceCall.webServiceResponse(intentRequest,callback)

}