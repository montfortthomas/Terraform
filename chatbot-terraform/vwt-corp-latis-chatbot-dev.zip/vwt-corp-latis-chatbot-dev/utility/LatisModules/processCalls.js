'use strict';
//Importing Functional Modules
const OtherLangAnswer = require('./Faqs/getOtherLangAnswer');
const EnglishAnswer = require('./Faqs/getEnglishAnswer');
const Templates = require("../CommonModules/helperFunctions");
const Session = require("./session");
const CommonError = require('../CommonModules/commonErrorMessages')
const CommonFunction = require('../CommonModules/commonFunctions')
const DbCall = require('./dbUtils')
const userInput=require('./GuidedResolution/BatchInError/userInput')
const intentNames=require('./Constants/intentNames.json')
const aliasIntents=require('./Constants/aliasIntentNames.json')
const shipConfirmationInput=require('./GuidedResolution/ShipConfirmation/userInput');
const timeEntryServiceOrder = require('./GuidedResolution/TimeEntryServiceOrder/userInput');
const POCreationInput = require('../LatisModules/GuidedResolution/PoCreation/userInput');
const timeEntryInput=require('../LatisModules/GuidedResolution/TimeEntry/userInput')
const salesUpdateInput=require('../LatisModules/GuidedResolution/SalesUpdate/userInput')
const cafInput=require('../LatisModules/GuidedResolution/CAF/userInput')
const index=require('../../index')
const POReceivedInput = require('./GuidedResolution/PoReceiving/userinput')
const poPrintInput = require('../LatisModules/GuidedResolution/PoPrint/userInput')
const poCreationInput = require('../LatisModules/GuidedResolution/PoCreation/userInput')
const poReceiptInput = require('../LatisModules/GuidedResolution/PoReceipt/userInput')
const batchErrorInput = require('../LatisModules/GuidedResolution/BatchInError/userInput');


//Check for intent values and redirect to answer
exports.modelDatabaseCall = async function (intentRequest, callback) {
    console.log("the modal Database hit");
    console.log("the session in data base call", intentRequest);
    var sessionAttributes = intentRequest.sessionAttributes;
    // Trigger Module based on the language
    
    if (sessionAttributes.SourceCode !== 'en') {
        // Triggered in case of any other language other than english
        await OtherLangAnswer.getOtherLangAnswer(intentRequest, callback);
    }
    else {   // Triggered in case of english language 
            await EnglishAnswer.getEnglishAnswer(intentRequest, callback);
        }
        
    }


// Fetch Roll Out to be passed to service now
exports.fetchRollOut = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    var rollOutObj, rollOut
    try {
        // Trigger a Database call to fetch the rollout based on user country
        rollOutObj = await DbCall.fetchRollOut(sessionAttributes.country, callback)
        if (rollOutObj) {
            rollOut = rollOutObj.Item.RollOut.S;
            if (sessionAttributes.country === 'France') {
                if (!sessionAttributes.userRollOut) {
                    // Trigger the roll out menu for french user for the first time
                    sessionAttributes.RollOutFR = rollOut;
                    return await this.frenchRollOutMenu(rollOut, intentRequest, callback);
                }
                else {
                    // if the roll out already exists in table then set it without the prompt
                    sessionAttributes.rollOut = sessionAttributes.userRollOut
                }
            }
            else {
                sessionAttributes.rollOut = rollOut
            }
        }
        // trigger the send mail function
        return await this.sendMail(intentRequest, callback)
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
}

exports.sendMail = async function (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes;
    const type = "Response";
    var message;
    // Trigger the mail function
    try {
        var mailReceived = await CommonFunction.triggerMail(intentRequest, callback);
        // If Promise is returned as true
        if (mailReceived) {
            // Reset the service now variables in the session
            sessionAttributes.serviceNowTriggred = 'false'
            sessionAttributes.serviceNowStage = null
            // Translate the message if not english
            const results = await DbCall.callMenuTable('ThankYou Message', sessionAttributes.SourceCode);
            const resultsEn = await DbCall.callMenuTable('ThankYou Message', 'en');
            if(results)
            {
                message = results.Item.message.S;
            }
            else
            {
                message = resultsEn.Item.message.S
                message = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, message); 
            }
            sessionAttributes.Confirmation="notSatisfied";
            Session.setCurrentOutputType(sessionAttributes, type);
            return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
        // If the Promise is returned as false and the email is not sent
        else {
            // Reset the service now variables
            sessionAttributes.serviceNowTriggred = 'false'
            sessionAttributes.serviceNowStage = null
            if (sessionAttributes.SourceCode !== "en") {
                message = " I am facing some issue while raising an incident for you. Please try again later"
                message = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, message);
            }
            else {
                message = " I am facing some issue while raising an incident for you. Please try again later"
            }
            Session.setCurrentOutputType(sessionAttributes, type);
            return Templates.getResponseTemplateFour(sessionAttributes, message, callback);
        }
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }

}
// Fetch the Roll Out Menu for French Users
exports.frenchRollOutMenu = async function (rollOut, intentRequest, callback) {
    console.log("French Roll out triggred");
    var sessionAttributes = intentRequest.sessionAttributes;
    var intentName = intentRequest.currentIntent.name;
    const type = "Menu";
    var frenchRollOutMenu = [], frenchTranslatedMenu = [], btn = [];
    var frenchRollOutStr, translatedMenu, ButtonData;
    var message = "Please select the rollOut"

    // Split the Roll out as France is associated with multiple roll outs
    try
    {
    frenchRollOutMenu = rollOut.split(',');
    if (sessionAttributes.SourceCode !== 'en') {
        frenchRollOutStr = frenchRollOutMenu.toString();
        translatedMenu = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, frenchRollOutStr);
        console.log("the translated menu",translatedMenu)
       frenchTranslatedMenu = translatedMenu.split(",");
   
       console.log("the french split menus", frenchTranslatedMenu )
        for (let initialValue in frenchRollOutMenu) {
            console.log("initial value", initialValue);
            btn.push({
                text: frenchTranslatedMenu[initialValue],
                Value: frenchRollOutMenu[initialValue]
            });
        }
    }
    else {
        console.log('in the else of en');
        for (let value in frenchRollOutMenu) {
            btn.push({
                text: frenchRollOutMenu[value],
                Value: frenchRollOutMenu[value]
            });
        }
    }

    if (sessionAttributes.SourceCode !== "en") {
        message = await CommonFunction.modeltranslation(sessionAttributes.SourceCode, message);
    }
    ButtonData = Templates.getButtons(btn);
    console.log("the button data", ButtonData);
    const AppState = intentName;
    Session.setCurrentIntent(sessionAttributes, intentName);
    Session.setCurrentOutputType(sessionAttributes, type);
    Session.setCurrentAppState(sessionAttributes, AppState);
    // set the service now stage as rollOut
    sessionAttributes.serviceNowStage = 'rollOut'
    console.log("the roll out session set", sessionAttributes);
    return Templates.getResponseCardTemplateTwo(sessionAttributes, message, ButtonData, callback);
    }
    catch(error)
    {
        await CommonError.generalError(intentRequest, callback)
    }
}

exports.previousIntentFlow=async function (intentRequest, callback) {
    console.log("previous intent flow hit");
    var sessionAttributes = intentRequest.sessionAttributes
    switch (sessionAttributes.previousIntent) {
        case intentNames.shipConfirmGuidedResolution: await shipConfirmationInput.inputParameters(intentRequest, callback)
            break;
        case intentNames.timeEntryGuidedResolution:
                await timeEntryInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poPrintGuidedResolution:
                await poPrintInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poCreationGuidedResolution:
                await poCreationInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poReceiptGuidedResolution:
            await POReceivedInput.validateInput(intentRequest,callback);
            break;
        case intentNames.cafGuidedResolution:
                await cafInput.validateInput(intentRequest, callback);
            break;
        case intentNames.salesUpdateGuidedResolution: console.log("the sales update hit in previous intent");
            await salesUpdateInput.validateInput(intentRequest, callback);
            break;
        case intentNames.timeEntryServiceOrderResolution:
            await timeEntryServiceOrder.validateInput(intentRequest, callback);
            break;
        case intentNames.poCreationError:
            await POCreationInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poMatchingReceipt : console.log("matching receipt hit in previous flow");
            await POMatchingErrorInput.validateInput(intentRequest,callback);
            break;
        case intentNames.batchErrorGuidedResolution : 
            await batchErrorInput.validateInput(intentRequest,callback);
            break;
        case intentNames.voucherMatchGuidedResolution:
            await poReceiptInput.validateInput(intentRequest,callback);
            break;
        default:
            sessionAttributes.previousIntent=null;
            sessionAttributes.intentStage=null;
            await index.dispatch(intentRequest,callback)
            break;
    }
}



