'use strict';
// Import node modules
let request = require("request");
let util = require('util');
request = util.promisify(request);
const AWS = require('aws-sdk');
// Configure AWS specific modules
AWS.config.update({ region: "eu-west-1" });
const dynamoDB = new AWS.DynamoDB();

// Importing the functional modules
const CommonError = require('../CommonModules/commonErrorMessages')

// Fetch the answer from the table
exports.getAnswer = async function (intentName) {
    try {
        var params = {
            TableName: "vwt_corp_latis_chatbot_dev",
            IndexName: "Topic",
            KeyConditionExpression: "Topic = :Topic",
            ExpressionAttributeValues: {
                ":Topic": { 'S': intentName }
            },
        };
        var result = await dynamoDB.query(params).promise()
        if (JSON.stringify(result) !== '{}') {
            return result;
        }
        else {
            return false;
        }
    } catch (error) {
        console.error(error);
        await CommonError.generalError(intentRequest, callback)
    }
}
// DB call to fetch the language of the user
exports.fetchLang = async function (userIdFromJde, sessionAttributes) {
    try {
        const params = {
            TableName: "vwt_corp_latis_language",
            Key:
            {
                'UserId': {
                    'S': userIdFromJde
                }
            }
        }
        const results = await dynamoDB.getItem(params).promise();
        if (results.Item) {
            sessionAttributes.userIdDb = results.Item.UserId.S
            if (results.Item.Lang) {
                if (results.Item.RollOut) {
                    sessionAttributes.userRollOut = results.Item.RollOut.S
                }
                else {
                    sessionAttributes.userRollOut = null;
                }
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
}

// DB call to update the language of the user
exports.updateLang = async function (slotValue, userId) {
    try {
        var docClient = new AWS.DynamoDB.DocumentClient()
        var params = {
            TableName: "vwt_corp_latis_language",
            Key: {
                "UserId": userId
            },
            UpdateExpression: "set Lang = :l",
            ExpressionAttributeValues: {
                ":l": slotValue,
            },
            ReturnValues: "UPDATED_NEW"
        };
        var response = await docClient.update(params, function (err, data) {
            if (err) {
                console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
              //  return data;
            }
            
        });
        return response;
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
}
// Fetch the answer of the translate table in case of any other language
exports.callTranslateTable = async function (intentName, langCode) {
    try {
        var params = {
            TableName: "vwt_corp_latis_translated_response_dev",
            IndexName: "Topic",
            KeyConditionExpression: "Topic = :Topic AND LangCode=:LangCode",
            ExpressionAttributeValues: {
                ":Topic": { 'S': intentName },
                ":LangCode": { 'S': langCode }
            },
        };
        var result = await dynamoDB.query(params).promise()
        console.log(JSON.stringify(result))
        if (JSON.stringify(result) !== '{}') {
            return result;
        }
        else {
            return false;
        }
    } catch (error) {
        console.error(error);
        await CommonError.generalError(intentRequest, callback)
    }

}
// Fetch the menus in the table
exports.callMenuTable = async function (itemMenu, langCode) {
        var params = {
            Key: {
                "ItemMenu": { "S": itemMenu },
                "LangCode": { "S": langCode },
            },
            TableName: "vwt_corp_latis_chatbot_menu_dev"
        };
        var result = await dynamoDB.getItem(params).promise()
        console.log(JSON.stringify(result))
        if (JSON.stringify(result) !== '{}') {

            return result;
        }
        else {
            return false;
        }
};
// DB call to get the alias of a sub module
exports.getAlias = async function (subModule,callback) {
    try {
        var params = {
            TableName: "vwt_corp_latis_chatbot_dev",
            IndexName: "SubModule",
            KeyConditionExpression: "SubModule = :SubModule",
            ExpressionAttributeValues: {
                ":SubModule": { 'S': subModule }
            },

        };
        var result = await dynamoDB.query(params).promise()
        console.log(JSON.stringify(result))
        if (JSON.stringify(result) !== '{}') {
            return result;
        }
        else {
            return false;
        }
    } catch (error) {
        console.error(error);
        await CommonError.generalError(intentRequest, callback)
    }

}
// DB call to get the sub modules from the table
exports.getSubModules = async function (moduleName,callback) {
    try {
        var params = {
            TableName: "vwt_corp_latis_chatbot_dev",
            IndexName: "ItemMenu",
            KeyConditionExpression: "ItemMenu = :ItemMenu",
            ExpressionAttributeValues: {
                ":ItemMenu": { 'S': moduleName }
            },

        };
        var result = await dynamoDB.query(params).promise()
        console.log(JSON.stringify(result))
        if (JSON.stringify(result) !== '{}') {

            return result;
        }
        else {
            return false;
        }
    } catch (error) {
        console.error(error);
        await CommonError.generalError(intentRequest, callback)
    }

}
// DB call to fetch the roll out
exports.fetchRollOut = async function (country, callback) {
    try {
        const params = {
            TableName: "vwt_corp_latis_chatbot_rollout",
            Key:
            {
                'Country': {
                    'S': country
                }
            }
        }
        const results = await dynamoDB.getItem(params).promise();
        if (results) {
            return results
        }
        else {
            return null
        }
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }

}
// DB call to update the rollOut as per user selection
exports.updateRollOut = async function (userIdJde, intentRequest, callback) {
    try {
        var sessionAttributes = intentRequest.sessionAttributes
        var docClient = new AWS.DynamoDB.DocumentClient()
        var params = {
            TableName: "vwt_corp_latis_language",
            Key: {
                "UserId": userIdJde
            },
            UpdateExpression: "set RollOut = :r",
            ExpressionAttributeValues: {
                ":r": sessionAttributes.rollOut,
            },
            ReturnValues: "UPDATED_NEW"
        };
        console.log("Updating the item...");
        docClient.update(params, function (error, data) {
            if (error) {
                console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
            }
        });
    }
    catch (error) {
        await CommonError.generalError(intentRequest, callback)
    }
}
exports.updateUserId = async function (userIdJde) {

        var params = {
            Item: {
                UserId: {
                    S: userIdJde
                }
            },
            ReturnConsumedCapacity: "TOTAL",
            TableName: 'vwt_corp_latis_language',
        };

        dynamoDB.putItem(params, function (err, data) {
            if (err) {
                console.log(err, err.stack);
            }
            else {
                console.log(data);
            }
        });
    }
