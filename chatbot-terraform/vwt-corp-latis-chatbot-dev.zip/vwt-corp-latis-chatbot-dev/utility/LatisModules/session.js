'use strict';
var exports = module.exports = {};
exports.setTime = function(sessionAttributes, time) {
    console.log("setting attributes 1 attributes");
    sessionAttributes.time = time;
    console.log("setting attributes 1 attributes", );
};

exports.getTime = function(sessionAttributes) {
    console.log("get session attributes",  sessionAttributes.time);

    return sessionAttributes.time;
    
};

exports.setCurrentIntent = function(sessionAttributes, IntentName) {
    sessionAttributes.IntentName = IntentName;
    console.log("setting IntentName attributes ", IntentName);
};

exports.getCurrentIntent = function(sessionAttributes) {
    console.log("get IntentName attributes ", sessionAttributes.IntentName);
    return sessionAttributes.IntentName;
};

exports.setCurrentAppState = function(sessionAttributes, AppState) {
    sessionAttributes.AppState = AppState;
    console.log("setting AppState attributes", AppState);
};

exports.getCurrentAppState = function(sessionAttributes) {
    console.log("get AppState attributes", sessionAttributes.AppState);
    return sessionAttributes.AppState;
};

exports.setCurrentOutputType = function(sessionAttributes, OutputType) {
    sessionAttributes.OutputType = OutputType;
    console.log("setting OutputType attributes", );
};

exports.getCurrentOutputType = function(sessionAttributes) {
    console.log("get OutputType attributes", );
    return sessionAttributes.OutputType;
};

//for confirmation
exports.setConfirmation = function(sessionAttributes, Confirmation) {
    sessionAttributes.Confirmation = Confirmation;
    console.log("setting Confirmation attributes", );
};

exports.getConfirmation = function(sessionAttributes) {
    console.log("get Confirmation attributes", );
    return sessionAttributes.Confirmation;
};
exports.setserviceNowTriggred = function(sessionAttributes, serviceNowTriggred) {
    sessionAttributes.serviceNowTriggred = serviceNowTriggred;
    console.log("setting snow attribute", );
};

exports.getserviceNowTriggred = function(sessionAttributes) {
    console.log("get Confirmation attributes", );
    return sessionAttributes.serviceNowTriggred;
};
