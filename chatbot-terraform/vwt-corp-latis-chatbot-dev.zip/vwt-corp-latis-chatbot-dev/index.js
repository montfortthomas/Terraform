'use strict';
//Importing all modules
const processCalls = require('./utility/LatisModules/processCalls');
const getHelpMenu = require('./utility/LatisModules/Faqs/getModule');
const getSubModule = require('./utility/LatisModules/Faqs/getSubModules');
const getAlias = require('./utility/LatisModules/Faqs/getAlias');
const greetingMessage = require('./utility/LatisModules/greetingMessage');
const validation = require('./utility/LatisModules/validations')
const constantValues = require('./utility/LatisModules/Constants/constants.json');
const intentNames = require('./utility/LatisModules/Constants/intentNames.json');
const aliasIntents = require('./utility/LatisModules/Constants/aliasIntentNames.json');
const errorMessages = require('./utility/CommonModules/commonErrorMessages');
const commonResponse = require('./utility/CommonModules/commonResponseMessages');
const serviceNowParams = require('./utility/CommonModules/serviceNowParams');
const DbCall = require('./utility/LatisModules/dbUtils');
const shipConfirmationInput = require('./utility/LatisModules/GuidedResolution/ShipConfirmation/userInput');
const timeEntryInput = require('./utility/LatisModules/GuidedResolution/TimeEntry/userInput')
const salesUpdateInput = require('./utility/LatisModules/GuidedResolution/SalesUpdate/userInput')
const timeEntryServiceOrder = require('./utility/LatisModules/GuidedResolution/TimeEntryServiceOrder/userInput');
const poPrintInput = require('./utility/LatisModules/GuidedResolution/PoPrint/userInput')
const poCreationInput = require('./utility/LatisModules/GuidedResolution/PoCreation/userInput')
const poReceiptInput = require('./utility/LatisModules/GuidedResolution/PoReceipt/userInput')
const cafInput = require('./utility/LatisModules/GuidedResolution/CAF/userInput')
const batchInput = require('./utility/LatisModules/GuidedResolution/BatchInError/userInput')
const poReceivingInput = require('./utility/LatisModules/GuidedResolution/PoReceiving/userinput')

//method to dispatch to other functions
exports.dispatch = async function (intentRequest, callback) {
    console.log(`dispatch  intentName=${intentRequest.currentIntent.name}`);
    console.log("In Disptacher function", intentRequest);

    //This will hold the current intent and slot values which is being hit by the user
    var intentName = intentRequest.currentIntent.name;
    //This will hold the variables which will be valid through the session along with the data coming from the widget
    const sessionAttributes = intentRequest.sessionAttributes;
    sessionAttributes.userinput = intentRequest.inputTranscript;
    //Trigger validation function if the user is not validated
    if (!sessionAttributes.validation) {
        sessionAttributes.validation = await validation.userValidation(sessionAttributes);
    }
    console.log("check session after ldap", sessionAttributes);
    //Source Language Detection Failure
    if (sessionAttributes.SourceCode === undefined) {
        sessionAttributes.SourceCode = constantValues.defaultLang
    }
    //Check if it is valid LATIS User
    if (sessionAttributes.validation) {
        //for help intents
        sessionAttributes.ticketCreated = null
        sessionAttributes.endGreetings = null;
        sessionAttributes.userSatisfied = null;
        var checkForHelpKey = intentName.toLowerCase().includes("help") || intentName.toLowerCase().includes("livecheck");
        console.log("this is sessionatrributes confirmation", sessionAttributes.Confirmation)
        if (sessionAttributes.Confirmation === 'notSatisfiedInput') {
            console.log("in not satisfied input")
            sessionAttributes.notSatisfiedInput = intentRequest.inputTranscript;
            sessionAttributes.Confirmation = null;
            await commonResponse.modelFurtherAssistance(intentRequest, callback);
        }
        else {
            //If User Asks to Create an incident on ServiceNow
            if (sessionAttributes.serviceNowTriggred === 'true') {

                await serviceNowResponse(intentRequest, callback)
            }
            else {
                if (sessionAttributes.previousIntent) {
                    console.log("the previous intent hit");
                    await processCalls.previousIntentFlow(intentRequest, callback)
                }
                else {
                    //Condition to check if any other intent is hit other than the intents for FAQ
                    if (intentName !== intentNames.endGreetings_intent && checkForHelpKey === false && intentName !== intentNames.changeLangIntent && checkForHelpKey === false && intentName !== intentNames.greetings_intent && checkForHelpKey === false && intentName !== intentNames.response_yes_intent && checkForHelpKey === false && intentName !== intentNames.response_no_intent) {
                        //Trigger the database call if any other intent is hit
                        sessionAttributes.serviceNowFlow = null;
                        // await processCalls.modelFetchAnswer(intentRequest, callback)
                        await processCalls.modelDatabaseCall(intentRequest,callback)
                    }
                    else {
                        await getIntentResponse(intentRequest, callback)
                    }
                }
            }
        }
    }
    // Will be executed, If not a valid user
    else {
        //This will execute if any of the validations fail
        await errorMessages.modelNotAuthorised(intentRequest, callback);
    }
}

// exports.getIntentResponse=async function(intentRequest,callback)
async function getIntentResponse(intentRequest, callback) {
    var intentName = intentRequest.currentIntent.name;
    var slots = intentRequest.currentIntent.slots;
    var sessionAttributes = intentRequest.sessionAttributes;
    if (JSON.stringify(aliasIntents).includes(intentName))
        intentName = 'getAlias'
    console.log("this is intentName in getIntentResponse..", intentName)
    switch (intentName) {
        case 'getAlias': await getAlias.modelFetchAlias(intentRequest, callback);
            break;
        case intentNames.timeEntryGuidedResolution: await timeEntryInput.validateInput(intentRequest, callback);
            break;
        case intentNames.shipConfirmGuidedResolution: await shipConfirmationInput.inputParameters(intentRequest, callback);
            break;
        case intentNames.poPrintGuidedResolution: await poPrintInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poCreationGuidedResolution: await poCreationInput.validateInput(intentRequest, callback);
            break;
        case intentNames.salesUpdateGuidedResolution: await salesUpdateInput.validateInput(intentRequest, callback);
            break;
        case intentNames.poReceiptGuidedResolution: await poReceivingInput.validateInput(intentRequest, callback);
            break;
        case intentNames.cafGuidedResolution: await cafInput.validateInput(intentRequest,callback);
            break;
        case intentNames.batchErrorGuidedResolution: await batchInput.validateInput(intentRequest,callback);
            break;  
        case intentNames.timeEntryServiceOrderResolution : await timeEntryServiceOrder.validateInput(intentRequest, callback);
            break;
        case intentNames.voucherMatchGuidedResolution : await poReceiptInput.validateInput(intentRequest, callback);
            break;  
        case intentNames.greetings_intent: await greetingMessage.modelGreetingResponse(intentRequest, callback);
            break;
        case intentNames.changeLangIntent: await greetingMessage.modelChangeLanguage(intentRequest, callback);
            break;
        case intentNames.response_yes_intent:
            switch (sessionAttributes.Confirmation) {
                case "confirm": await commonResponse.modelResponse(intentRequest, callback);
                    break;
                case "satisfied":
                    sessionAttributes.userSatisfied = "Satisfied"
                    await commonResponse.modelFurtherAssistance(intentRequest, callback);
                    break;
                case "serviceNow":
                    if (sessionAttributes.serviceNowFlow === "guidedResolution") {
                        console.log("in service now guided resolution")
                        sessionAttributes.serviceNowTriggred = true;
                        await commonResponse.serviceNowUrgency(intentRequest, callback)
                    }
                    else {
                        await commonResponse.shortDescription(intentRequest, callback)
                    }
                    break;
                case "FurtherAssistance": await commonResponse.modelFurtherAssistanceHelp(intentRequest, callback)
                    break;
                case 'guidedResolutionSnow': await commonResponse.modelResponseNo(intentRequest, callback);
                    break;
                case 'notSatisfied': await commonResponse.notSatisfiedInput(intentRequest, callback);
                    break;
                default: break;
            }
            break;
        case intentNames.response_no_intent:
            switch (sessionAttributes.Confirmation) {
                case 'guidedResolutionSnow': await commonResponse.modelResponse(intentRequest, callback);
                    break;
                case "satisfied":
                    sessionAttributes.userSatisfied = "Not Satisfied"
                    if (sessionAttributes.serviceNowFlow === "guidedResolution") {
                        sessionAttributes.serviceNowFlow = null;
                        await commonResponse.modelFurtherAssistance(intentRequest, callback);

                    }
                    else {
                       // await commonResponse.notSatisfiedInput(intentRequest, callback)
                         await commonResponse.modelResponseNo(intentRequest, callback);
                    }
                    break;
                case "FurtherAssistance":
                    sessionAttributes.endGreetings = "Yes"
                    await commonResponse.modelEndGreetings(intentRequest, callback);
                    break;
                case "serviceNow":
                    if (sessionAttributes.serviceNowFlow === "guidedResolution") {
                        await commonResponse.modelResponse(intentRequest, callback);
                    }
                    else {
                        await commonResponse.notSatisfiedInput(intentRequest, callback)
                        
                    }
                    break;
                default: break;
            }
            break;
        case intentNames.endGreetings_intent:
            sessionAttributes.endGreetings = "Yes"
            await commonResponse.modelEndGreetings(intentRequest, callback);
            break;
        case constantValues.randomChracters: await errorMessages.modelErrorHandling(intentRequest, callback);
            break;
        case intentNames.unresolvedChracters: await errorMessages.modelErrorHandling(intentRequest, callback);
            break;
        case intentNames.furtherAssistance_intent: await commonResponse.modelFurtherAssistance(intentRequest, callback);
            break;
        case intentNames.furtherAssistance_intent:
            switch (slots.LATIS_Yes_No) {
                case null: await commonResponse.modelFurtherAssistanceHelp(intentRequest, callback);
                    break;
                case "No": await commonResponse.modelEndGreetings(intentRequest, callback);
                    break;
                default: break;
            }
            break;
        case intentNames.help_intent:
            if (slots.HelpMenu === null) {
                await getHelpMenu.modelHelpResponse(intentRequest, callback);
            }
            else if (slots.HelpMenu !== null) {
                await getSubModule.modelSubModules(intentRequest, callback);
            }
            break;
        default:
            break;

    }
}
async function serviceNowResponse (intentRequest, callback) {
    var sessionAttributes = intentRequest.sessionAttributes
    switch (sessionAttributes.serviceNowStage) {
        //If the Bot is asking to type the description
        case 'description': await serviceNowParams.validateDescription(intentRequest, callback);
            break;
        //Check if the bot is asking to select urgency
        case 'urgency': await serviceNowParams.validateUrgency(intentRequest, callback);
            break;
        //Check If the bot is asking to select the category
        case 'category': await serviceNowParams.validateCategory(intentRequest, callback)
            break;
        case 'rollOut': await serviceNowParams.validateRollouts(intentRequest, callback);
            break;
        default:
            await serviceNowParams.validateShortDesc(intentRequest, callback);
    }
}


// --------------- Main handler -----------------------
exports.handler = (event, context, callback) => {
    try {
        console.log(`event.bot.name=${event.bot.name}`);
        this.dispatch(event, (response) => callback(null, response));
    } catch (err) {
        callback(err);
    }
};

